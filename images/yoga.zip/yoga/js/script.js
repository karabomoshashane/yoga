// Toggle navigation menu for mobile devices
function toggleMenu() {
    const nav = document.querySelector('nav ul');
    nav.classList.toggle('show');
}

// Feedback form validation
function validateFeedbackForm(event) {
    event.preventDefault();
    const email = document.getElementById('email').value.trim();
    const comments = document.getElementById('comments').value.trim();
    let errorMessage = '';

    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
        errorMessage += 'Please provide a valid email address. ';
    }
    if (!comments) {
        errorMessage += 'Comments cannot be empty. ';
    }

    if (errorMessage) {
        alert(errorMessage);
    } else {
        alert('Thank you for your feedback!');
        event.target.reset();
    }
}

// Booking form validation
function validateBookingForm(event) {
    event.preventDefault();
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    let errorMessage = '';

    if (!name) {
        errorMessage += 'Name cannot be empty. ';
    }
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
        errorMessage += 'Please provide a valid email address. ';
    }

    if (errorMessage) {
        alert(errorMessage);
    } else {
        alert('Your class has been booked! We will contact you soon.');
        event.target.reset();
    }
}

// Execute when DOM is fully loaded
document.addEventListener("DOMContentLoaded", function () {
    // Feedback form submission
    const feedbackForm = document.querySelector('.feedback-form');
    if (feedbackForm) {
        feedbackForm.addEventListener('submit', validateFeedbackForm);
    }

    // Booking form submission
    const bookingForm = document.querySelector('.booking-form');
    if (bookingForm) {
        bookingForm.addEventListener('submit', validateBookingForm);
    }

    // Mobile navigation toggle
    const toggleButton = document.querySelector('.menu-toggle');
    if (toggleButton) {
        toggleButton.addEventListener('click', toggleMenu);
    }
});